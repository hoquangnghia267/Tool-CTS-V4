log_file_path = "C:\\Users\Administrator\Desktop\Tool-CTS-V4\log\CAv4.log"  # Thay thế bằng đường dẫn thật của bạn

import tkinter as tk
import subprocess

# Đường dẫn cụ thể đến file log
log_file_path = "C:\\Users\Administrator\Desktop\Tool-CTS-V4\log\CAv4.log"

def open_log_in_notepad(file_path):
    try:
        subprocess.Popen(['notepad.exe', file_path])
    except Exception as e:
        error_message = f"Không thể mở file log bằng Notepad: {e}"
        error_label.config(text=error_message)

# Tạo cửa sổ chính
root = tk.Tk()
root.title("Log Viewer")

# Tạo nút để mở file log bằng Notepad
open_button = tk.Button(root, text="Open Log in Notepad", command=lambda: open_log_in_notepad(log_file_path))
open_button.pack(pady=10)

# Tạo label để hiển thị thông báo lỗi nếu có
error_label = tk.Label(root, text="", fg="red")
error_label.pack(pady=10)

# Chạy vòng lặp chính của Tkinter
root.mainloop()
