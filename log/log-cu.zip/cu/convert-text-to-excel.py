# import pandas as pd
# import os

# # Đường dẫn đến thư mục chứa các file .txt
# folder_path = r'C:\\Users\Administrator\Desktop\Tool-CTS-V4\log'

# # Tạo một danh sách để lưu trữ dữ liệu từ tất cả các file
# all_data = []

# # Lặp qua tất cả các file trong thư mục
# for filename in os.listdir(folder_path):
#     if filename.endswith('.log'):
#         file_path = os.path.join(folder_path, filename)
#         with open(file_path, 'r') as file:
#             # Đọc nội dung của file
#             data = file.readlines()
#             # Xử lý và thêm dữ liệu vào danh sách
#             for line in data:
#                 all_data.append(line.strip().split(','))  # Giả sử các trường được phân cách bởi dấu phẩy

# # Chuyển danh sách dữ liệu thành DataFrame của pandas
# df = pd.DataFrame(all_data, columns=['Column1', 'Column2', 'Column3'])  # Đặt tên cột tương ứng

# # Xuất DataFrame thành file Excel
# excel_path = 'output.xlsx'
# df.to_excel(excel_path, index=False)

# print(f'Data has been exported to {excel_path}')

import pandas as pd
import os

# Đường dẫn đến thư mục chứa các file .log
folder_path = r'C:\Users\Administrator\Desktop\Tool-CTS-V4\log'

# Tạo một danh sách để lưu trữ dữ liệu từ tất cả các file
all_data = []

# Lặp qua tất cả các file trong thư mục
for filename in os.listdir(folder_path):
    if filename.endswith('.log'):
        file_path = os.path.join(folder_path, filename)
        with open(file_path, 'r', encoding='utf-8') as file:
            # Đọc nội dung của file
            data = file.readlines()
            # Xử lý và thêm dữ liệu vào danh sách
            for line in data:
                all_data.append(line.strip().split(','))  # Giả sử các trường được phân cách bởi dấu phẩy

# Xác định số lượng cột lớn nhất
max_columns = max(len(row) for row in all_data)

# Chuyển danh sách dữ liệu thành DataFrame của pandas với số lượng cột xác định
df = pd.DataFrame(all_data, columns=[f'Column{i+1}' for i in range(max_columns)])

# Xuất DataFrame thành file Excel
excel_path = r'C:\Users\Administrator\Desktop\Tool-CTS-V4\output.xlsx'
df.to_excel(excel_path, index=False)

print(f'Data has been exported to {excel_path}')
